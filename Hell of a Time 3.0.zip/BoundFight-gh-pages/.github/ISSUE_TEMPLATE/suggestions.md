---
name: Suggestions
about: I have some suggestions
title: ''
labels: enhancement
assignees: ''

---

You should add:
