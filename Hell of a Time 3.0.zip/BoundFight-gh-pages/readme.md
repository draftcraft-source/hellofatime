**On days like this massacists like us should just...**
![B U R N  I N  H E L L](https://camo.githubusercontent.com/639231eaa69ca047f4360976df813a61fd57ec11/68747470733a2f2f7777772e64656d697272616d6f6e2e636f6d2f67656e2f756e64657274616c655f746578745f626f782e6769663f746578743d4225323055253230522532304e253230253230492532304e25323025323048253230452532304c2532304c26626f783d756e64657274616c6526626f78636f6c6f723d7768697465266368617261637465723d637573746f6d2675726c3d6874747073253341253246253246692e696d6775722e636f6d2532463933567064766e2e706e672663686172636f6c6f723d776869746526666f6e743d64657465726d696e6174696f6e26617374657269736b3d74727565266d6f64653d726567756c617226616e696d6174653d66616c7365)

**Have fun, and have a hell of a day.**

________________________________________________________________________________

# Credit

**Recolor/Color Palette by: Me**

**Some attacks by: [estebanfer](https://www.reddit.com/user/estebanfer)**

**Original Hard Mode: [gotoAndDie](https://github.com/gotoAndDie)**

**Original: [Jcw87](https://github.com/Jcw87)**

**Song Used: [SOLLICITUS II](https://soundcloud.com/ragher/swapped-realities-sollicitus-updated)**

**Song Creator: [Judge](https://soundcloud.com/ragher)**

**Final Attack(s): [Mush 2 Blue](https://www.youtube.com/channel/UCMHwpcP2P4AbV1tDgz5N5XA)**
